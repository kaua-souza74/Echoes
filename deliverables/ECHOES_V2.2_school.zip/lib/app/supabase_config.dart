import 'dart:convert';

class SupabaseConfig {
  const SupabaseConfig(this.url, this.key);
  final String url, key;
  factory SupabaseConfig.environment() => const SupabaseConfig(
    String.fromEnvironment('SUPABASE_URL'),
    String.fromEnvironment(
      'SUPABASE_PUBLISHABLE_KEY',
      defaultValue: String.fromEnvironment('SUPABASE_ANON_KEY'),
    ),
  );
  void validate() {
    final uri = Uri.tryParse(url);
    if (uri == null ||
        uri.scheme != 'https' ||
        uri.host.isEmpty ||
        key.isEmpty) {
      throw const FormatException(
        'Configuração pública de acesso ausente ou inválida.',
      );
    }
    if (key.startsWith('sb_publishable_')) return;
    try {
      final pieces = key.split('.');
      if (pieces.length == 3) {
        final payload =
            jsonDecode(
                  utf8.decode(base64Url.decode(base64Url.normalize(pieces[1]))),
                )
                as Map;
        if (payload['role'] == 'anon') {
          if (uri.host.endsWith('.supabase.co') &&
              payload['ref'] != uri.host.split('.').first) {
            throw const FormatException(
              'Projeto e chave pública não correspondem.',
            );
          }
          return;
        }
      }
    } catch (error) {
      if (error is FormatException &&
          error.message == 'Projeto e chave pública não correspondem.') {
        rethrow;
      }
    }
    throw const FormatException(
      'Use somente uma chave pública anon ou publishable.',
    );
  }
}
